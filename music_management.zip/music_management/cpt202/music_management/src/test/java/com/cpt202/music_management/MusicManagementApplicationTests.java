package com.cpt202.music_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
