package com.cpt202.music_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicManagementApplication.class, args);
	}

}
